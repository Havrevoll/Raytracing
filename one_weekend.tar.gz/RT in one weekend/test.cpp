#include <iostream>
#include "vec3.h"

int main()
{
	std::cout << "Hei" << std::endl;

	vec3 ola(3.0,4.0,5.0);
	std::cout << ola << std::endl;
	return 0;
}
